
using System;

namespace CURPLibrary
{
    public class CurpGenerator
    {
        public string Nombre { get; set; }
        public string ApellidoPaterno { get; set; }
        public string ApellidoMaterno { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public string Sexo { get; set; } // H o M
        public string EntidadFederativa { get; set; }
        public string CURPGenerada { get; private set; }

        public event EventHandler CURPActualizada;

        private bool ValidarEntradas()
        {
            if (string.IsNullOrWhiteSpace(Nombre) ||
                string.IsNullOrWhiteSpace(ApellidoPaterno) ||
                string.IsNullOrWhiteSpace(ApellidoMaterno) ||
                string.IsNullOrWhiteSpace(Sexo) ||
                string.IsNullOrWhiteSpace(EntidadFederativa) ||
                FechaNacimiento == default)
                return false;

            return true;
        }

        public void GenerarCURP()
        {
            if (!ValidarEntradas())
                throw new InvalidOperationException("Todos los campos son obligatorios y deben ser válidos.");

            CURPGenerada = GenerarCurpOficial();
            OnCURPActualizada();
        }

        protected virtual void OnCURPActualizada()
        {
            CURPActualizada?.Invoke(this, EventArgs.Empty);
        }

        private string GenerarCurpOficial()
        {
            string curp = $"{ApellidoPaterno[0]}{PrimerVocalInterna(ApellidoPaterno)}{ApellidoMaterno[0]}{Nombre[0]}" +
                          $"{FechaNacimiento:yyMMdd}{Sexo.ToUpper()}{EntidadFederativa.ToUpper().Substring(0, 2)}" +
                          $"{PrimeraConsonanteInterna(ApellidoPaterno)}{PrimeraConsonanteInterna(ApellidoMaterno)}{PrimeraConsonanteInterna(Nombre)}" +
                          "00";
            return curp.ToUpper();
        }

        private char PrimerVocalInterna(string palabra)
        {
            for (int i = 1; i < palabra.Length; i++)
            {
                if ("AEIOU".Contains(char.ToUpper(palabra[i])))
                    return char.ToUpper(palabra[i]);
            }
            return 'X';
        }

        private char PrimeraConsonanteInterna(string palabra)
        {
            for (int i = 1; i < palabra.Length; i++)
            {
                char c = char.ToUpper(palabra[i]);
                if (!"AEIOU".Contains(c) && Char.IsLetter(c))
                    return c;
            }
            return 'X';
        }
    }
}
