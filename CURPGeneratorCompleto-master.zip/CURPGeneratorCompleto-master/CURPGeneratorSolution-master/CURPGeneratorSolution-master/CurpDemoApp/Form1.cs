﻿using CurpControlLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CurpDemoApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //curpControl1.CurpGenerada += curpControl1_CurpGenerada;
        }

        private void curpControl1_CurpGenerada(object sender, EventArgs e)
        {
            // Mostrar la CURP generada al usuario
            //MessageBox.Show("CURP actualizada: " + curpControl1.CURPGenerada);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // Aquí puedes agregar código para cuando se cargue el formulario
        }

    }
}
