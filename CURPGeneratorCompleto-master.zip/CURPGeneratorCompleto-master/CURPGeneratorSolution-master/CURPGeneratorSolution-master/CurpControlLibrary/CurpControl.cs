﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CurpControlLibrary
{
    public partial class CurpControl : UserControl
    {
        public CurpControl()
        {
            InitializeComponent();
            txtNombre.TextChanged += (s, e) => ActualizarCURP();
            txtApellidoP.TextChanged += (s, e) => ActualizarCURP();
            txtApellidoM.TextChanged += (s, e) => ActualizarCURP();
            cmbSexo.SelectedIndexChanged += (s, e) => ActualizarCURP();
            cmbEntidad.SelectedIndexChanged += (s, e) => ActualizarCURP();
            dtpFechaNacimiento.ValueChanged += (s, e) => ActualizarCURP();
        }
        public string Nombre => txtNombre.Text.Trim().ToUpper();
        public string ApellidoPaterno => txtApellidoP.Text.Trim().ToUpper();
        public string ApellidoMaterno => txtApellidoM.Text.Trim().ToUpper();
        public DateTime FechaNacimiento => dtpFechaNacimiento.Value;
        public string Sexo => cmbSexo.SelectedItem?.ToString().Substring(0, 1).ToUpper() ?? "";
        public string EntidadFederativa => cmbEntidad.SelectedItem?.ToString() ?? "";
        public string CURPGenerada => txtCurpGenerada.Text;

        public event EventHandler CurpGenerada;

        private void ActualizarCURP()
        {
            if (ValidarEntradas())
            {
                string curp = GenerarCURP(); 
                txtCurpGenerada.Text = curp;
                CurpGenerada?.Invoke(this, EventArgs.Empty); 
            }
        }

        private bool ValidarEntradas()
        {
            return !string.IsNullOrWhiteSpace(Nombre)
                && !string.IsNullOrWhiteSpace(ApellidoPaterno)
                && !string.IsNullOrWhiteSpace(ApellidoMaterno)
                && cmbSexo.SelectedItem != null
                && cmbEntidad.SelectedItem != null;
        }

        private string GenerarCURP()
        {
            string anio = FechaNacimiento.Year.ToString().Substring(2, 2);
            string mes = FechaNacimiento.Month.ToString("D2");
            string dia = FechaNacimiento.Day.ToString("D2");

            string sexo = Sexo;
            string entidad = EntidadFederativa.Substring(0, 2);

            return $"{ApellidoPaterno[0]}{ApellidoMaterno[0]}{Nombre[0]}{anio}{mes}{dia}{sexo}{entidad}XX00"; 
        }

        private void txtNombre_TextChanged(object sender, EventArgs e) => ActualizarCURP();
        private void txtApellidoP_TextChanged(object sender, EventArgs e) => ActualizarCURP();
        private void txtApellidoM_TextChanged(object sender, EventArgs e) => ActualizarCURP();
        private void cmbSexo_SelectedIndexChanged(object sender, EventArgs e) => ActualizarCURP();
        private void cmbEntidad_SelectedIndexChanged(object sender, EventArgs e) => ActualizarCURP();
        private void dtpFechaNacimiento_ValueChanged(object sender, EventArgs e) => ActualizarCURP();


    }
}
